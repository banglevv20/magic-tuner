#!/system/bin/sh
########################################
######## Magic Tuner Uninstaller #######
########################################

echo "========================================"
echo " Magic Tuner Addon Uninstaller – cleaning up..."
sleep 2
echo " Removing all tweaks and restoring system state..."
echo "========================================"
echo ""

# IMPORTANT:
# This file is REQUIRED.
# Add here all revert or cleanup commands for your addon.
# Every tweak, setting, or property you added during install
# MUST be deleted, reset, or undone here.

# Examples:
# settings delete global example_key
# settings delete system screen_brightness_mode
# settings delete secure double_tap_to_wake
# resetprop --delete persist.sys.myaddon.flag

# When uninstalling, the app will ONLY execute this file.
# If you leave it empty, your addon’s tweaks will remain active.
