ID=Addons
name=gaming vulkan
version=1.0
author=bang levv
description=This addon is designed to optimize specific system parameters, providing better performance and smoother response. Built for stability and clean integration with Magic Tuner.
magicver=5232
