#!/system/bin/sh
########################################
######## MAGIC TUNER PROPS SETUP #######
########################################

# THIS SCRIPT HANDLES ALL SYSTEM PROPERTIES (setprop)
# BY DEFAULT, ONLY DEBUG PROPERTIES (STARTING WITH "debug.") ARE SUPPORTED
# IF THE DEVICE HAS ROOT ACCESS, ALL PROPERTIES ARE ALLOWED

# IMPORTANT:
# DO NOT USE "echo" OR "sleep" COMMANDS IN THIS FILE
# THIS SCRIPT MUST RUN SILENTLY WITHOUT ANY UI OUTPUT

# EXAMPLES:
# setprop debug.hwui.renderer skiagl
# setprop debug.sf.hw 1
# setprop debug.performance.tuner true
