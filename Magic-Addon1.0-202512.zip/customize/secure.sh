#!/system/bin/sh
########################################
######## MAGIC TUNER SECURE SETUP ######
########################################

# THIS SCRIPT HANDLES ALL SECURE SETTINGS
# ONLY USE "settings put secure ..." COMMANDS HERE
# EACH SETTING ADDED HERE MUST BE DELETED IN "uninstall/uninstall.sh"

# IMPORTANT:
# DO NOT USE "echo" OR "sleep" COMMANDS IN THIS FILE
# THIS SCRIPT MUST RUN SILENTLY WITHOUT ANY UI OUTPUT

# EXAMPLES:
# settings put secure double_tap_to_wake 0
# settings put secure accessibility_enabled 1
# settings put secure doze_always_on 0
