#!/system/bin/sh
########################################
######## MAGIC TUNER GLOBAL SETUP ######
########################################

# THIS SCRIPT HANDLES ALL GLOBAL SETTINGS
# ONLY USE "settings put global ..." COMMANDS HERE
# EACH SETTING ADDED HERE MUST BE DELETED IN "uninstall/uninstall.sh"

# IMPORTANT:
# DO NOT USE "echo" OR "sleep" COMMANDS IN THIS FILE
# THIS SCRIPT MUST RUN SILENTLY WITHOUT ANY UI OUTPUT

# EXAMPLES:
# settings put global show_touches 1
# settings put global animator_duration_scale 0.5
# settings put global stay_on_while_plugged_in 3
