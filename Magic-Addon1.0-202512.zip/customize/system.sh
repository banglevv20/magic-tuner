#!/system/bin/sh
########################################
######## MAGIC TUNER SYSTEM SETUP ######
########################################

# THIS SCRIPT HANDLES ALL SYSTEM SETTINGS
# ONLY USE "settings put system ..." COMMANDS HERE
# EACH SETTING ADDED HERE MUST BE DELETED IN "uninstall/uninstall.sh"

# IMPORTANT:
# DO NOT USE "echo" OR "sleep" COMMANDS IN THIS FILE
# THIS SCRIPT MUST RUN SILENTLY WITHOUT ANY UI OUTPUT

# EXAMPLES:
# settings put system screen_brightness_mode 0
# settings put system screen_off_timeout 60000
# settings put system accelerometer_rotation 1
