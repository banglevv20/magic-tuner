#!/system/bin/sh
##############################################
######## Addons Magic Tuner Template #########
##############################################

echo "========================================"
echo " Magic Tuner Addon Installer – preparing environment..."
sleep 2
echo " Please wait while the module is being deployed..."
echo "========================================"
sleep 3
echo ""

# instruction:
# use 'settings put global ...' inside global.sh  
# use 'settings put system ...' inside system.sh  
# use 'settings put secure ...' inside secure.sh  
# use 'setprop ...' inside props.sh


# All uninstall or revert tweaks must go inside uninstall/uninstall.sh.
# That’s the only script the app will execute during removal, so every settings delete, resetprop,
# or any cleanup command must be written there — nothing goes anywhere else.

##############################################
# type here any info you want to display
# echo "example: version, dev name, or any custom message"

##############################################
# type your custom debug properties below (only supports properties starting with 'debug.')
{ 
	# example
	# setprop debug.egl.hw 1
	# setprop debug.example true
	
} > /dev/null 2>&1
